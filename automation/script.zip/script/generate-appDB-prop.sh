#!/bin/bash


#Defining constants

declare -r INVALID_CHAR='#-'

function get_app_property {
       
        local key="$1"
	while read -r line
        do
        	local prop_value
		if !  [[ $line =~ ^[$INVALID_CHAR]  ]]; then
		
			if [[  $(echo "$line" | cut -d'=' -f1)= = $key ]]; then
		
		          local SUBSTRING
			  SUBSTRING=$(echo "$line" | cut -d'=' -f2)
		     	  echo $key$SUBSTRING
			  set -x
                          sed -i '' "/^"$key"/ s/$/"$SUBSTRING"/"  ./application-DB-template.properties
                          set +x

			fi
	        fi

	done < "$APPLICATION_PROP_FILE" 
}

function find_n_replace {
	
	local app_value
	get_app_property "$1"
	#sed -i ''  's/$1/$app_value/g'  "$parent_path"/application-DB-template.properties
}


function read_dbprop_template {
	
	while read -r line
	do 
		if ! [[ $line =~ ^[$INVALID_CHAR]  ]]; then
			get_app_property "$line"
	    	fi
        done < "$1"
}

# if [ "$#" -le 5 ]

 
parent_path="$(cd "$( dirname "${BASHSOURCE[0]}"  )" && pwd )"	
 
APPLICATION_PROP_FILE="${parent_path}"/application-DB.properties
cp -p "${parent_path}"/application-DB-template.properties.bak.1 "${parent_path}"/application-DB-template.properties
read_dbprop_template  "${parent_path}"/application-DB-template.properties

exit 0
